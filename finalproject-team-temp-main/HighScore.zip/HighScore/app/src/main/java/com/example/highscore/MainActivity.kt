package com.example.highscore

import android.accounts.AuthenticatorDescription
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.rv_recyclerView


class MainActivity : AppCompatActivity() {

    private var titlesList = mutableListOf<String>()
    private var descriptionList = mutableListOf<String>()
    private var imagesList = mutableListOf<Int>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rv_recyclerView.LayoutManager = LinearLayoutManager(this)
        rv_recyclerView.adapter = RecyclerAdapter(titlesList, descriptionList, imagesList)


    }
    private fun addToList(title:String, description: String, image: Int){
        titlesList.add(title)
        descriptionList.add(description)
        imagesList.add(image)
    }
    private fun postToList(){
        for(i:Int in 1..25){
            addToList("title $i", "Description $i", R.mipmap.ic_launcher_round)

        }
    }
}